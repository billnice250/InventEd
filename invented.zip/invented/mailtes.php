<?php
mail('elie.gash@gmail.com','Wow','wonderful you made it bro','From: elie.gash42@gmail.com');


?>
