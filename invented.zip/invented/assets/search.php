<!-- Search tab -->
<div  id="searchTab">
        <div class="overlay">
            <div class="content">
                <form role="search" id="search-box" action="assets/script.php" method="POST">
                    <div class="input-group" >
                      <input  class="form-control" placeholder="Search for a question here..." type="text" name="content">
                    <div class="input-group-btn">
                    <button class="btn" type="submit" name="search"><i class="searchButton fa fa-search"></i></button>
                    </div>
                    </div>
                </form>
            </div>
        </div>
</div>
<!-- End of Search tab -->